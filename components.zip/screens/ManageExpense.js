import { Text, View } from "react-native";

function ManageExpense() {
    return (
        <View>
            <Text>ManageExpense</Text>
        </View>
    )
}

export default ManageExpense;
